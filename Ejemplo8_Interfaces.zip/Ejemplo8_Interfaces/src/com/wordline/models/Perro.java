package com.wordline.models;

import java.io.Serializable;

// Herencia multiple
public class Perro extends Animal implements IProductoVenta, Serializable {

	private String codigo;
	private double precio;

	public Perro() {
		// TODO Auto-generated constructor stub
	}

	public Perro(String nombre, int edad, String codigo, double precio) {
		super(nombre, edad);
		this.codigo = codigo;
		this.precio = precio;
	}

	@Override
	public String getCodigo() {
		return codigo;
	}

	@Override
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	@Override
	public double getPrecio() {
		return precio;
	}

	@Override
	public void setPrecio(double precio) {
		this.precio = precio;
	}

	@Override
	public String toString() {
		return "Perro [codigo=" + codigo + ", precio=" + precio + ", toString()=" + super.toString() + "]";
	}
	
	

}
