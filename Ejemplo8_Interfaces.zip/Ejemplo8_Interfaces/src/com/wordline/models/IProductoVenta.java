package com.wordline.models;

public interface IProductoVenta {
	
	// Las propiedades en las interface se entienden como constantes
	//public static final int VALOR = 5;
	int VALOR = 5;
	
	// Por defecto, todos los metodos de una interface son publicos y abstractos
	public abstract String getCodigo();
	void setCodigo(String codigo);
	
	public double getPrecio();
	abstract void setPrecio(double precio);
	
	
	// Novedades en Java 8 y Java 11
	// Metodos estaticos
	public static void metodoEstatico() {
		// Los metodos estaticos solo pueden acceder a recursos estaticos
		System.out.println("Metodo estatico " + VALOR);
	}
		
	// Metodos default
	// La palabra default te permite tener metodos implementados en la interface
	public default String mostrar(String nombre) {
		return "Mayusculas: " + nombreMayusculas(nombre) + 
				" Minusculas: " + nombreMinusculas(nombre);
	}
	
	// Metodos privados
	// No necesito marcarlo como estatico o default
	private String nombreMayusculas(String nombre) {
		return nombre.toUpperCase();
	}
	
	private String nombreMinusculas(String nombre) {
		return nombre.toLowerCase();
	}

}
