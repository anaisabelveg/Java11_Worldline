package com.wordline;

import com.wordline.models.IProductoVenta;
import com.wordline.models.Perro;

public class AppMain {

	public static void main(String[] args) {
		
		Perro perro = new Perro("Fifi", 1, "PE-001", 295.90);
		System.out.println(perro);
		
		// Metodo estatico
		IProductoVenta.metodoEstatico();
		
		System.out.println(perro.mostrar(perro.getNombre()));

	}

}
