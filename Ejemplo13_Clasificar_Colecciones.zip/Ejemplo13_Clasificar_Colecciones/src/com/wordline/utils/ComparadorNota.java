package com.wordline.utils;

import java.util.Comparator;

import com.wordline.models.Alumno;

public class ComparadorNota implements Comparator<Alumno> {

	@Override
	public int compare(Alumno alum1, Alumno alum2) {
		// retorna 1 o cualquier num > 0 la instancia es mayor que el otro recibido
		// retorna -1 o cualquier num < 0 la instancia es menor que el otro recibido
		// retorna 0 la instancias son iguales
		if (alum1.getNota() > alum2.getNota()) {
			return 1;
		} else if (alum1.getNota() < alum2.getNota()) {
			return -1;
		} else {
			return 0;
		}
	}

}
