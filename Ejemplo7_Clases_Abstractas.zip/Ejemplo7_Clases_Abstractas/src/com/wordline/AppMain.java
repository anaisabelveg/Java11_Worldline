package com.wordline;

import com.wordline.models.Circulo;
import com.wordline.models.Figura;
import com.wordline.models.Rectangulo;

public class AppMain {

	public static void main(String[] args) {
		
		// No podemos crear objetos de una clase abstracta, esta incabada
		// Pero si la podemos utilizar como tipo de dato
		//Figura figura = new Figura(5,3);
		
		Circulo circulo = new Circulo(5, 3, 22.67);
		System.out.println("Area: " + circulo.calcularArea());
		System.out.println(circulo);
		
		Rectangulo rectangulo = new Rectangulo(7, 3, 200, 150);
		System.out.println("Area: " + rectangulo.calcularArea());
		System.out.println(rectangulo);

	}

}
