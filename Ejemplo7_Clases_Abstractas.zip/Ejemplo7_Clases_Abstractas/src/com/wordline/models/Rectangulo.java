package com.wordline.models;

public class Rectangulo extends Figura {

	private int base;
	private int altura;

	public Rectangulo() {
		// TODO Auto-generated constructor stub
	}

	public Rectangulo(int x, int y, int base, int altura) {
		super(x, y);
		this.base = base;
		this.altura = altura;
	}

	@Override
	public double calcularArea() {
		// TODO Auto-generated method stub
		return 0;
	}

	public int getBase() {
		return base;
	}

	public void setBase(int base) {
		this.base = base;
	}

	public int getAltura() {
		return altura;
	}

	public void setAltura(int altura) {
		this.altura = altura;
	}

	@Override
	public String toString() {
		return  super.toString() + " base=" + base + ", altura=" + altura ;
	}
	
	

}
