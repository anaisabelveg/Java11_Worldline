/**
 * 
 */
/**
 * 
 */
module Ejemplo7_Clases_Abstractas {
}