/**
 * 
 */
/**
 * 
 */
module com.wordline.consumidor {

	// Necesito el modulo donde se declara la interface calculadora
	// requires nombre_modulo;
	requires com.wordline.servicio;
	
	// Necesito indicar cual es la interface
	uses com.wordline.interfaz.ItfzCalculadora;
}