package com.wordline;

import java.util.Scanner;

public class BucleWhile {

	public static void main(String[] args) {
		
		// Mostrar los numeros del 1 al 10
		int numero = 1;
		while(numero <= 10) {
			System.out.println(numero);
			numero++;
		}
		
		// Solicitar un pw al usuario hasta que acierte que es curso
		String pw = "";
		while(! pw.equals("curso")) {
			Scanner sc = new Scanner(System.in);
			System.out.println("Introduce password: ");
			pw = sc.next();
		}
		System.out.println("Por fin, acertaste");

	}

}
