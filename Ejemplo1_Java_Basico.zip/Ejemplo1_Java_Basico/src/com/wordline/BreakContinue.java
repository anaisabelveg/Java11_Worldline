package com.wordline;

public class BreakContinue {

	public static void main(String[] args) {
		
		// Mostrar los numero primos del 1 al 100
		bucle_numeros:
		for(var numero=1; numero <= 100; numero++) {
			
			boolean esPrimo = true;
			
			for(var divisor = 2; divisor < numero; divisor++) {
				if (numero % divisor == 0) {
					esPrimo = false;
					// si ya tengo un divisor el numero no es primo
					// y no tiene sentido seguir buscando divisores
					// Primera opcion:
					//break;
					
					// Segunda opcion:
					continue bucle_numeros;
				}
			}
			
			if (esPrimo) System.out.println(numero);
			
		}

	}

}
