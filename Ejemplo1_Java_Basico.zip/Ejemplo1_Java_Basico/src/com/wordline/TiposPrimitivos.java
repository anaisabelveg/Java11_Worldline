package com.wordline;

public class TiposPrimitivos {

	// main + ctrl + space
	public static void main(String[] args) {
		
		// numeros enteros
		byte numByte = 10;     // 8bits     (byte)numero
		short numShort = 10000;  // 16 bits   (short)numero
		int  numInt = 10000000; // 32 bits  defecto
		long  numLong = 1000000000000000L;  // 64 bits
		
		// numeros reales
		float numFloat = 3.14F;  // 32 bits
		double numDouble = 3.14;  // 64 bits defecto 
		
		// booleanos
		boolean casado = true;    // solo admite true o false
		
		// character
		char letra = 'a';
		char espacio = ' ';
		char saltoLinea = '\n';
		char tabulador = '\t';
		
		// Cadenas de texto
		String saludo = "Bienvenidos al curso de Java";
		
		System.out.println("Contenido numByte: " + numByte);
		
		// Inferencia de tipos
		// La variable dato toma su tipo segun el valor asignado
		var dato = (short)4;
		//dato = "Hola";   // Error, porque la variable es numerica
		dato = 8000;
		
		// Esto no funciona porque al no tener asignado un valor, no infiere el tipo
		//var algo;
		var algo = "Valor inicial";
		
		
	}

}
