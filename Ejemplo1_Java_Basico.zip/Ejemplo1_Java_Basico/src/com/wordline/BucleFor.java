package com.wordline;

public class BucleFor {
	
	public static void main(String[] args) {
		
		// Mostrar los numeros del 1 al 10
		for(var num = 1; num <= 10; num++)
			System.out.println(num);
		System.out.println("-------------------");
		
		// Mostrar los numeros del 10 al 1
		for(var num = 10; num > 0; num--)
			System.out.println(num);
		System.out.println("-------------------");
		
		// Mostrar los numeros del 0 al 10, de 2 en 2
		for(var num = 0; num <= 10; num += 2)
			System.out.println(num);
		System.out.println("-------------------");
		
		// Mostrar las tablas de multiplicar
		for(var tabla = 1; tabla <= 10; tabla++) {
			System.out.println("********** Tabla del numero: " + tabla + " *************");
			
			for(var num = 1; num <= 10; num++) {
				System.out.println(tabla + " x " + num + " = " + (tabla*num));
			}
		}
	}

}
