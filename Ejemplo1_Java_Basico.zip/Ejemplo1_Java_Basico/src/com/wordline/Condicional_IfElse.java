package com.wordline;

public class Condicional_IfElse {

	public static void main(String[] args) {
		
		int numero = 37;
		
		// Condicional mas basico
		if (numero % 2 == 0) System.out.println("El numero es par");
		
		// Condicional if-else
		if (numero % 2 == 0) 
			System.out.println("El numero es par");
		else
			System.out.println("El numero es impar");
		
		// Operador ternario
		System.out.println((numero % 2 == 0) ? "El numero es par" : "El numero es impar" );
		
		// Condicional anidado
		if (numero % 2 == 0) {
			System.out.println("Es divisible por 2");
		} else if (numero % 3 == 0) {
			System.out.println("Es divisible por 3");
		} else if (numero % 5 == 0) {
			System.out.println("Es divisible por 5");
		} else {
			System.out.println("El numero " + numero + " no es divisible ni por 2, 3, 5");
		}
			

	}

}
