package com.wordline;

public class Operadores {
	
	public static void main(String[] args) {
		// Operadores aritmeticos:
		System.out.println("Resto de la division o modulo: " + (7%3));
		
		int num1 = 7;
		// num1++  post-incremento   1º muestra el valor y 2º incrementa
		System.out.println(num1++);  // la variable num1 se incrementa en 1
		System.out.println(num1);
		
		int num2 = 7;
		// ++num2  pre-incremento   1º incrementa  y 2º muestra el valor
		System.out.println(++num2);
		System.out.println(num2);
		
		// cuando incremento o decremento solo en una linea, no afecta el resultado
		num1--;
		--num1;
		
		
		// Operadores realicionales
		var a = 9;
		var b = 4;
		System.out.println("a es mayor que b? " + (a > b));
		
		// Estas comprobaciones de igualdad o desigualdad solo funcionan con tipos primitivos
		System.out.println("a es igual a b? " + (a == b));
		System.out.println("a es distinto a b? " + (a != b));
		
		// Excepcion, los String si que se pueden comparar
		var nombre1 = "Juan";
		var nombre2 = "Juan";	
		System.out.println("son iguales los nombres? " + (nombre1 == nombre2));
		
		
		
		// Operadores logicos
		System.out.println((a > b)  && (a++ == 9));
		System.out.println((a > b)  || (a++ == 5));
		System.out.println( !(a > b));
		
		
		// Operadores de asignacion
		a += 2;     // a = a + 2;
		a -= 2;     // a = a - 2;
		a *= 2;     // a = a * 2;
		a /= 2;     // a = a / 2;
		a %= 2;     // a = a % 2;
	}

}
