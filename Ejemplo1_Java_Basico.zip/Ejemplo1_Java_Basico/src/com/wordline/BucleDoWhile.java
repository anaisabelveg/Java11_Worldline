package com.wordline;

import java.util.Scanner;

public class BucleDoWhile {

	public static void main(String[] args) {
		
		// Juego de adivinar numero dando pistas
		
		// Generar un numero aleatorio del 1 al 10
		int aleatorio = (int) (Math.random()*10) + 1;
		int numero = 0;
		
		do {
			Scanner sc = new Scanner(System.in);
			System.out.println("Adivina numero: ");
			numero = sc.nextInt();
			
			if (aleatorio > numero){
				System.out.println("Te has quedado corto, prueba de nuevo");
			} else if (aleatorio < numero){
				System.out.println("Te has pasado, prueba de nuevo");
			}
			
		} while (aleatorio != numero);
		System.out.println("Por fin, acertaste");
		
	}

}
