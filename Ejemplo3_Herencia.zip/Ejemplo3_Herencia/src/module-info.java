/**
 * 
 */
/**
 * 
 */
module Ejemplo3_Herencia {
}