package com.wordline;

import com.wordline.models.Empleado;
import com.wordline.models.Persona;

public class Principal {

	public static void main(String[] args) {
		
		Empleado empleado = new Empleado("Juan", 37, 56000);
		empleado.setEdad(38);
		empleado.setSueldo(60000);
		System.out.println("Nombre: " + empleado.getNombre());
		
		// Cuando mostramos el objeto internamente llama al metodo toString()
		System.out.println(empleado);
		
		// == compara el contenido de las variables, para comparar objetos no vale
		// equals y hascode son los que utilizamos para comparar objetos
		Empleado empl1 = new Empleado("Maria", 45, 57000);
		Empleado empl2 = new Empleado("Maria", 45, 57000);
		//Empleado empl2 = empl1;
		System.out.println("Los empleados son iguales? " + (empl1 == empl2));
		System.out.println("Los empleados son iguales? " + empl1.equals(empl2));
		
		int num1 = 8;
		int num2 = 8;
		System.out.println("Los numeros son iguales? " + (num1 == num2));
		
		// Polimorfismo; es la capacidad de ver el mismo objeto de multiples formas
		long numero = (byte) 5;  
		numero = (short) 5;
		numero =  5; 
		numero = 5L;
		
		Persona persona = new Empleado("Juan", 37, 56000);  // Empleado es una Persona
		Object objeto = new Empleado("Juan", 37, 56000);    // Empleado es un Object
		
		// El empleado lo estoy viendo como un objeto
		//objeto.getNombre();
		
		// Al empleado lo estoy viendo como una persona
		//persona.getSueldo();
		
		// No podemos cambiar la forma del objeto pero si como lo vemos
		// El tipo de la variable que apunta al objeto es quien determina como lo vemos
		// Como cambiamos la visibilidad??
		Empleado otro = (Empleado) persona;
		Empleado otroMas = (Empleado) objeto;
		
	}

}
