package com.wordline;

import com.wordline.business.ItfzFuncional;

public class AppMain {

	public static void main(String[] args) {
		
		// lambda (parametros) -> cuerpo de la funcion
		ItfzFuncional lambda1 = (nombre, edad) -> "nombre: " + nombre + " edad: " + edad;
		System.out.println(lambda1.infoPersonas("Pepito", 36));
		
		ItfzFuncional lambda2 = (String nombre, int edad) -> "nombre: " + nombre + " edad: " + edad;
		System.out.println(lambda2.infoPersonas("Pepito", 36));
		
		ItfzFuncional lambda3 = (nombre, edad) -> {
			return "nombre: " + nombre + " edad: " + edad;
		};
		System.out.println(lambda3.infoPersonas("Pepito", 36));

		ItfzFuncional lambda4 = (nombre, edad) -> {
			edad++;
			nombre = nombre.toUpperCase();
			return "nombre: " + nombre + " edad: " + edad;
		};
		System.out.println(lambda4.infoPersonas("Pepito", 36));
		
		// Cuando utilizo llaves, es obligatorio poner return
		ItfzFuncional lambda5 = (nombre, edad) -> {
			edad++;
			nombre = nombre.toUpperCase();
			"nombre: " + nombre + " edad: " + edad;   // error porque falta return 
		};
		System.out.println(lambda5.infoPersonas("Pepito", 36));

	}

}
