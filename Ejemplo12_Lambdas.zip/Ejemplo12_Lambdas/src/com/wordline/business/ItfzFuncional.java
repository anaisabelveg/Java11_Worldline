package com.wordline.business;

// Es una interface funcional porque solo tenemos un metodo abstracto
@FunctionalInterface
public interface ItfzFuncional {
	
	String infoPersonas(String nombre, int edad);

}
