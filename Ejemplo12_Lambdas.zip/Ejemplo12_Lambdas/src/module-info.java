/**
 * 
 */
/**
 * 
 */
module Ejemplo12_Lambdas {
}