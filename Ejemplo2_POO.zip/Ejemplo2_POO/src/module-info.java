/**
 * 
 */
/**
 * 
 */
module Ejemplo2_POO {
}