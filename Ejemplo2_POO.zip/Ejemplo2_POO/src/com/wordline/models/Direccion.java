package com.wordline.models;

public class Direccion {
	
	public String calle;
	public int numero;
	public String poblacion;
	
	public Direccion() {
		// TODO Auto-generated constructor stub
	}

	public Direccion(String calle, int numero, String poblacion) {
		super();
		this.calle = calle;
		this.numero = numero;
		this.poblacion = poblacion;
	}
	
	public String mostrarInfo() {
		// Mayor, 5 - Madrid
		return calle + ", " + numero + " - " + poblacion;
	}

}
