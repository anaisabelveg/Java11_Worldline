package com.wordline.models;

public class Cliente {
	
	// propiedades, campos, caracteristicas del Cliente
	public String nombre;
	public String CIF;
	public boolean vip;
	public Direccion direccion;

	// El compilador, si la clase no tiene ningun constructor
	// agrega el constructor por defecto (sin parametros)
	// Mantener el constructor por defecto
	public Cliente() {
		// TODO Auto-generated constructor stub
	}
	
	
	// Crear el constructor completo (recibe todos los valores de las propiedades)
	public Cliente(String nombre, String CIF, boolean vip, Direccion direccion) {
		super();
		// puntero this.
		// this.recurso
		this.nombre = nombre;
		this.CIF = CIF;
		this.vip = vip;
		this.direccion = direccion;
	}
	
	
	// metodos, funciones, acciones
	public String mostrarInfo() {
		return "Nombre: " + nombre + " CIF: " + CIF + " VIP: " + vip 
				+ " Direccion: " + direccion.mostrarInfo();
	}
	
	
	// Cuando el metodo no retorna nada es de tipo void
	public void cambiarVip(boolean nuevoValor) {
		vip = nuevoValor;
	}

}
