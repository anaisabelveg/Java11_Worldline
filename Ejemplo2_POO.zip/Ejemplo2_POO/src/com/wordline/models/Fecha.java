package com.wordline.models;

public class Fecha {
	
	public int dia;
	public int mes;
	public int anyo;
	
	public String mostrarFecha() {
		return dia + "/" + mes + "/" + anyo;
	}

}
