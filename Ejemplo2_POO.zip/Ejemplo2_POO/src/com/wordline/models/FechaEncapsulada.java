package com.wordline.models;

/*
 * Una clase encapsulada, define todas sus propiedades como privadas
 * y se accede a ellas a través de métodos get() y set() publicos
 * */
public class FechaEncapsulada {

	// Los recursos privados solo son accesibles desde dentro de la clase
	private int dia;
	private int mes;
	private int anyo;

	// Metodos de lectura
	public int getDia() {
		return dia;
	}

	// Metodos de escritura
	public void setDia(int dia) {
		if (dia > 0 && dia <= 31)
			this.dia = dia;
		else
			System.out.println("El dia no es correcto");
	}

	public int getMes() {
		return mes;
	}

	public void setMes(int mes) {
		if (mes >= 1 && mes <= 12)
			this.mes = mes;
		else
			System.out.println("El mes no es correcto");
	}

	public int getAnyo() {
		return anyo;
	}

	public void setAnyo(int anyo) {
		if (anyo == 2024)
			this.anyo = anyo;
		else
			System.out.println("El año no es correcto");
	}

	public String mostrarFecha() {
		return dia + "/" + mes + "/" + anyo;
	}

}
