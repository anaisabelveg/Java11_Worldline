package com.wordline;

import com.wordline.models.Cliente;
import com.wordline.models.Direccion;
import com.wordline.models.Fecha;
import com.wordline.models.FechaEncapsulada;

public class AppMain {

	// La JVM reconoce este metodo main
	// La clase que contiene este metodo es la primera en ejecutarse
	// Con este metodo marcamos el punto de entrada a la aplicacion
	public static void main(String[] args) {
		
		// Crear un objeto o instancia de Cliente
		int numero = 8;
		Cliente cliente1 = new Cliente();   // new Constructor()
		
		// Asignar valores al objeto creado
		// objeto.recurso
		cliente1.nombre = "Fruteria Perez";
		cliente1.CIF = "B-12345678";
		cliente1.vip = false;
		cliente1.direccion = new Direccion("Mayor", 5, "Madrid");
		
		// Ver el objeto
		System.out.println(cliente1);
		// objeto.recurso
		System.out.println(cliente1.mostrarInfo());
		
		// Cambiar el objeto a vip
		// objeto.recurso
		cliente1.cambiarVip(true);
		System.out.println(cliente1.mostrarInfo());
		
		
		// Crear un segundo cliente y pasamos todos los datos al constructor
		Cliente cliente2 = new Cliente("Carniceria Santos", "B-98765432", false, 
				new Direccion("Diagonal", 87, "Barcelona"));
		System.out.println(cliente2.mostrarInfo());
		
		
		Fecha fecha = new Fecha();
		fecha.dia = 7876;
		fecha.mes = -35;
		fecha.anyo = 20246544;
		System.out.println(fecha.mostrarFecha());
		
		FechaEncapsulada fechaEncapsulada = new FechaEncapsulada();
		fechaEncapsulada.setDia(76545);
		fechaEncapsulada.setMes(76);
		fechaEncapsulada.setAnyo(-12);
		System.out.println(fechaEncapsulada.mostrarFecha());
		
		FechaEncapsulada fechaEncapsulada2 = new FechaEncapsulada();
		fechaEncapsulada2.setDia(7);
		fechaEncapsulada2.setMes(5);
		fechaEncapsulada2.setAnyo(2024);
		System.out.println(fechaEncapsulada2.mostrarFecha());
		

	}

}












