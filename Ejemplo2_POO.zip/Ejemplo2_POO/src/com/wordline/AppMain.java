package com.wordline;

import com.wordline.models.Cliente;
import com.wordline.models.Direccion;

public class AppMain {

	// La JVM reconoce este metodo main
	// La clase que contiene este metodo es la primera en ejecutarse
	// Con este metodo marcamos el punto de entrada a la aplicacion
	public static void main(String[] args) {
		
		// Crear un objeto o instancia de Cliente
		int numero = 8;
		Cliente cliente1 = new Cliente();   // new Constructor()
		
		// Asignar valores al objeto creado
		// objeto.recurso
		cliente1.nombre = "Fruteria Perez";
		cliente1.CIF = "B-12345678";
		cliente1.vip = false;
		cliente1.direccion = new Direccion("Mayor", 5, "Madrid");
		
		// Ver el objeto
		System.out.println(cliente1);
		// objeto.recurso
		System.out.println(cliente1.mostrarInfo());
		
		// Cambiar el objeto a vip
		// objeto.recurso
		cliente1.cambiarVip(true);
		System.out.println(cliente1.mostrarInfo());
		
		
		// Crear un segundo cliente y pasamos todos los datos al constructor
		Cliente cliente2 = new Cliente("Carniceria Santos", "B-98765432", false, 
				new Direccion("Diagonal", 87, "Barcelona"));
		System.out.println(cliente2.mostrarInfo());

	}

}
