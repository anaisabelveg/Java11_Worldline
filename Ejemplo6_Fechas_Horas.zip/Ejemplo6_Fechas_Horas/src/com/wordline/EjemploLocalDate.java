package com.wordline;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Month;
import java.time.temporal.TemporalAdjusters;

public class EjemploLocalDate {

	public static void main(String[] args) {
		
		// Fecha de hoy
		LocalDate hoy = LocalDate.now();
		System.out.println(hoy);
		
		// Crear la fecha de cumpleaños
		LocalDate miCumple = LocalDate.of(2024, Month.JULY, 1);
		System.out.println(miCumple);
		
		// Ha pasado ya mi cumpleaños?
		System.out.println("Ha pasado mi cumple? " + hoy.isAfter(miCumple));
		
		// En que dia de la semana va a ser micumple
		System.out.println("Cuando cae? " + miCumple.getDayOfWeek());
		
		// Es bisiesto este año
		System.out.println("Es bisiesto? " + miCumple.isLeapYear());
		
		// Fecha del proximo lunes
		System.out.println("Proximo lunes: " + hoy.with(TemporalAdjusters.next(DayOfWeek.MONDAY)));
		
		// Sumar un mes
		System.out.println("Dentro de un mes: " + hoy.plusMonths(1));
		
		// restar 3 dias
		System.out.println("Hace 3 dias: " + hoy.minusDays(3));
		
		// sumar 2 años
		System.out.println("En 2 años: " + hoy.plusYears(2));

	}

}
