package com.wordline;

import java.time.LocalTime;
import java.time.temporal.ChronoUnit;

public class EjemploLocalTime {

	public static void main(String[] args) {
		
		// Hora actual
		LocalTime ahora = LocalTime.now();
		System.out.println(ahora);
		
		// Solo hora:minutos
		System.out.println(ahora.truncatedTo(ChronoUnit.MINUTES));
		
		// Hora partido
		LocalTime partido = LocalTime.of(21, 0);
		System.out.println("Hora del partido: " + partido);
		
		// Cuanto queda para el partido
		System.out.println("Cuanto queda para el partido: " +
				ahora.until(partido, ChronoUnit.HOURS) + " horas");
		
		System.out.println("Cuanto queda para el partido: " +
				ahora.until(partido, ChronoUnit.MINUTES) + " minutos");

		// Tranformar a segundos, minutos, horas
		System.out.println(ahora.toSecondOfDay() + " segundos");
		System.out.println(ahora.toSecondOfDay() / 60 + " minutos");
		System.out.println(ahora.toSecondOfDay() / 60 / 60 + " horas");
	}

}
