package com.wordline;

import java.time.LocalDateTime;
import java.time.Month;
import java.time.ZoneId;
import java.time.ZonedDateTime;

public class EjemploZoneDateTime {

	public static void main(String[] args) {
		
		
		// Mostrar todas las zonas horarias
		//System.out.println(ZoneId.getAvailableZoneIds());
		
		// Crear la zona horaria
		ZoneId USEast = ZoneId.of("America/New_York");
		
		// Crear fecha y hora en España
		LocalDateTime spain = LocalDateTime.of(2023, Month.JULY, 19, 11, 50);
		ZonedDateTime horaSpain = ZonedDateTime.of(spain, ZoneId.of("Europe/Madrid"));
		System.out.println("Hora en España: " + horaSpain);
		
		// Hora de España en New York
		ZonedDateTime newYork = ZonedDateTime.of(spain, USEast);
		System.out.println("Hora en New York: " + newYork);
		System.out.println("Diferencia horaria con New York: " + newYork.getOffset());
		
		// Que hora es ahora en New York
		System.out.println("Ahora en New York: " + ZonedDateTime.now(USEast));

	}

}
