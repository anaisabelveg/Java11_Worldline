package com.wordline;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;

public class EjemploLocalDateTime {

	public static void main(String[] args) {
		
		// Mi vuelo es 10/Agosto/2024 a las 21:30
		LocalDateTime miVuelo = LocalDateTime.of(2024, Month.AUGUST, 10, 21, 30);
		System.out.println(miVuelo);
		
		// Otra forma
		LocalDate fecha = LocalDate.of(2024, Month.AUGUST, 10);
		LocalTime hora = LocalTime.of(21, 30);
		LocalDateTime miVuelo2 = LocalDateTime.of(fecha, hora);
		System.out.println(miVuelo2);
		
		// Adelantar mi vuelo 1 semana
		System.out.println(miVuelo.minusWeeks(1));
		
		// Posponer 1 mes mi vuelo
		System.out.println(miVuelo.plusMonths(1));

	}

}
