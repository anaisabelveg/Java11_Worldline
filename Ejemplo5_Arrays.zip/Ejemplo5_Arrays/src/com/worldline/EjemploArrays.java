package com.worldline;

import java.util.Arrays;

public class EjemploArrays {

	public static void main(String[] args) {
		// Los arrays son estructuras fijas, no son redimensionables
		// Todos los elementos del array son del mismo tipo
		
		//int num = 9;
		
		// Declarar una variable de tipo array
		int numeros[], a;   // a es una variable entera
		int[] numeros2, b;  // b es una variable de tipo array
		int [] numeros3, c; // c es una variable de tipo array
		
		// crear el array vacio
		numeros = new int[4];  // obligatorio dar longitud del array
		
		// crear el array con elementos
		numeros2 = new int[] {1,2,3,4,5,6};
		int[] numeros4 = {1,2,3,4,5,6};
		// De esta forma no funciona la inferencia de tipos,
		// en los arrays necesita el tipo de dato
		//var numeros5[] = {1,2,3,4,5,6};
		
		// acceder a los elementos
		// array[indice]
		numeros[0] = 1;
		numeros[1] = 10;
		numeros[2] = 100;
		numeros[3] = 1000;
		
		// recorrer una array
		for(int idx=0; idx < numeros.length; idx++) {
			System.out.println(numeros[idx]);
		}
		
		// a partir de Java 5 tenemos for-each
		for (int item : numeros4) {
			System.out.println(item);
		}
		
		// Como no son redimensionables, creo un array grande y copio los datos
		var grande = new int[10];
		System.arraycopy(numeros, 0, grande, 0, numeros.length);
		
		// Mostrar el array
		System.out.println(grande);
		System.out.println(Arrays.toString(grande));
	}

}
