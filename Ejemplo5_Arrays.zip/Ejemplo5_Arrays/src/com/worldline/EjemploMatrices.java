package com.worldline;

import java.util.Arrays;

public class EjemploMatrices {

	public static void main(String[] args) {
		
		// Declarar una variable matriz de 2 dimensiones
		int matriz[][];
		
		// Crear la matriz
		matriz = new int[2][3];  // [fila][columna]  6 elementos
		
		// Llenado de datos
		matriz[0][0] = 7;
		matriz[0][1] = 1;
		matriz[0][2] = 4;
		matriz[1][0] = 6;
		matriz[1][1] = 3;
		matriz[1][2] = 9;
		
		// Todo en 1
		var matriz2 = new int[][] { {7,1,4,2,5}, {6,3,9} };
		
		// for tradicional
		for(int fila=0; fila < matriz2.length; fila++) {
			for(int col=0; col < matriz2[fila].length; col++) {
				System.out.print(matriz2[fila][col] + "\t");
			}
			System.out.println();
		}
		
		// for-each
		for (int[] fila : matriz2) {
			for (int num : fila) {
				System.out.print(num + "\t");
			}
			System.out.println();
		}
		
		// Mostrar matrices
		System.out.println(matriz2);
		System.out.println(Arrays.toString(matriz2));
		System.out.println(Arrays.deepToString(matriz2));


	}

}
