/**
 * 
 */
/**
 * 
 */
module com.wordline.servicio {
	
	// exports paquete;
	exports com.wordline.interfaz;
}