package com.wordline.business;

import java.util.List;

import com.wordline.models.Producto;
import com.wordline.persistence.ProductosDAO;

public class NegocioTienda {
	
	ProductosDAO dao = new ProductosDAO();
	
	public List<Producto> todos(){
		return dao.consultarTodos();
	}
	
	public Producto buscar(int id) {
		return dao.buscarPorId(id);
	}

}
