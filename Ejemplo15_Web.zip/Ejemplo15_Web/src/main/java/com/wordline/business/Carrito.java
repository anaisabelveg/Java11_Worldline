package com.wordline.business;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.wordline.models.Producto;

public class Carrito implements Serializable{
	
	private List<Producto> contenido = new ArrayList<Producto>();
	private double importe;
	
	NegocioTienda tiendaBS = new NegocioTienda();
	
	public void agregarProducto(int id) {
		Producto p = tiendaBS.buscar(id);
		if (p.getID() != 0) {
			contenido.add(p);
			importe += p.getPrecio();
		}
	}
	
	public void sacarProducto(int id) {
		Producto encontrado = contenido.stream()
			.filter(p -> p.getID() == id)
			.findFirst()
			.get();
		
		contenido.remove(encontrado);
		importe -= encontrado.getPrecio();
	}
	
	public List<Producto> getContenido() {
		return contenido;
	}
	
	public double getImporte() {
		return importe;
	}

}
