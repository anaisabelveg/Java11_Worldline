package com.wordline.rest;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import org.json.JSONArray;
import org.json.JSONObject;

import com.wordline.business.NegocioTienda;
import com.wordline.models.Producto;

import jakarta.websocket.server.PathParam;

// http://localhost:8085/Ejemplo15_Web
@Path("/")
public class ProductosREST {
	
	private NegocioTienda tiendaBS = new NegocioTienda();
	
	// http://localhost:8085/Ejemplo15_Web/server/consultar
	@GET
	@Path("consultar")
	@Produces("application/json")
	public String todos() {
		List<Producto> lista = tiendaBS.todos();
		JSONArray array = new JSONArray(lista);	
		return array.toString();
	}
	
	// http://localhost:8085/Ejemplo15_Web/server/consultar/2
	@GET
	@Path("consultar/{id}")
	@Produces("application/json")
	public String buscar(@PathParam("id")  int id) {
		Producto producto = tiendaBS.buscar(id);
		JSONObject json = new JSONObject(producto);
		return json.toString();
	}

}








