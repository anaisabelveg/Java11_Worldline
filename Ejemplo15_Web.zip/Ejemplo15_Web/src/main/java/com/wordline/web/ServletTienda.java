package com.wordline.web;


import java.io.IOException;
import java.util.List;

import com.wordline.business.Carrito;
import com.wordline.business.NegocioTienda;
import com.wordline.models.Producto;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;



/**
 * Servlet implementation class ServletTienda
 */
@WebServlet("/tienda")
public class ServletTienda extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private NegocioTienda tiendaBS = new NegocioTienda();
	
	private String mostrarTodos(HttpServletRequest request, HttpServletResponse response) {
		// Consultar todos los productos
		List<Producto> lista = tiendaBS.todos();
		
		// Guardar la lista como un atributo de peticion
		request.setAttribute("lista", lista);
		
		// Retornar el nombre de la vista
		return "/todos.jsp";
	}
	
	private String buscarProducto(HttpServletRequest request, HttpServletResponse response) {
		int id = Integer.parseInt(request.getParameter("codigo"));
		Producto encontrado = tiendaBS.buscar(id);
		request.setAttribute("encontrado", encontrado);
		return "/mostrarProducto.jsp";
	}
	
	private String agregarProducto(HttpServletRequest request, HttpServletResponse response) {
		// Crear o recuperar la sesion del usuario
		HttpSession sesion = request.getSession(true); //igual getSession() crear o recuperar la sesion
		Carrito miCarro = (Carrito) sesion.getAttribute("miCarrito");
		
		if (miCarro == null) {
			miCarro = new Carrito();
			sesion.setAttribute("miCarrito", miCarro);
		}
		
		miCarro.agregarProducto(Integer.parseInt(request.getParameter("codigo")));
		return "/mostrarCarrito.jsp";
	}

	private String sacarProducto(HttpServletRequest request, HttpServletResponse response) {
		// recuperar la sesion del usuario y si no existe no la creamos
		HttpSession sesion = request.getSession(false); 
		Carrito miCarro = (Carrito) sesion.getAttribute("miCarrito");
		miCarro.sacarProducto(Integer.parseInt(request.getParameter("codigo")));
		return "/mostrarCarrito.jsp";
	}


	// Peticiones GET: consultas sin cambios en el servidor
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String vista = "/index.html";
		
		String opcion = request.getParameter("op");
		switch (opcion) {
			case "1": {
				vista = mostrarTodos(request, response);	
				break;
			}
			case "2": {
				vista = buscarProducto(request, response);
				break;
			}
			case "3": {
				vista = agregarProducto(request, response);
				break;
			}
			case "4": {
				vista = sacarProducto(request, response);
				break;
			}
		}
		// Seleccionar la pagina que mostrar el resultado
		RequestDispatcher rd = request.getRequestDispatcher(vista);
		
		// Continua la pagina
		rd.forward(request, response);
		
	}

	// Peticiones POST: Cambios (insertar, borrar, modificar), datos sensibles, datos muy extensos
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// redireccion al metodo doGet
		doGet(request, response);
	}

}
