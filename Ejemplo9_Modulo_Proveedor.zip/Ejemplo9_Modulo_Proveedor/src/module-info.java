/**
 * 
 */
/**
 * 
 */
module com.wordline.proveedor {
	
	// Necesito el modulo donde se declara la interface calculadora
	// requires nombre_modulo;
	requires com.wordline.servicio;
	
	// proporcionamos una clase que implementa el servicio
	provides com.wordline.interfaz.ItfzCalculadora with com.wordline.business.CalculadoraImpl;
	
}