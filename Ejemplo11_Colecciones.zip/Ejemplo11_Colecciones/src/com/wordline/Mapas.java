package com.wordline;

import java.util.HashMap;
import java.util.Map;

public class Mapas {

	public static void main(String[] args) {
		// Los mapas son estructuras donde sus elementos Key:Value
		// Las claves no se pueden repetir, sobreescribe el valor
		// Los valores si que se pueden repetir
		// No garantiza el orden de entrada
		
		Map<String, Double> alumnos = new HashMap<>();
		alumnos.put("Jorge", 9.8);
		alumnos.put("Ana", 3.7);
		alumnos.put("Miguel", 5.7);
		alumnos.put("Rocio", 9.8);
		alumnos.put("Angel", 6.5);
		alumnos.put("Sara", 8.3);
		alumnos.put("Ana", 5.0);   // Sobreescribir la nota de Ana
		
		System.out.println(alumnos);
		
		System.out.println("Nota de Angel: " + alumnos.get("Angel"));
		System.out.println("Nombres de los alumnos: " + alumnos.keySet());
		System.out.println("Notas de los alumnos: " + alumnos.values());
		System.out.println("Todos los elementos " + alumnos.entrySet());
		
		// Borrar una entrada
		alumnos.remove("Sara");
		System.out.println(alumnos.toString());

		for (Object obj : alumnos.entrySet()) {
			System.out.println(obj);
		}
	}

}
