package com.wordline;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

public class InferenciaTipos {

	public static void main(String[] args) {
		
		var lista = new ArrayList<>();   // lista de objetos
		var lista2 = new ArrayList<Integer>();   // lista de enteros
		var lista3 = new ArrayList<Integer>(Arrays.asList(1,2,3,4,5)); // lista con 5 numeros 
		var lista4 = new ArrayList<>(Arrays.asList(1,2,3,4,5));  // lista con 5 numeros
		
		var set = new HashSet<>();
		var set2 = new HashSet<String>();
		var set3 = new HashSet<String>(Arrays.asList("Juan", "Maria", "Pedro"));
		var set4 = new HashSet<>(Arrays.asList("Juan", "Maria", "Pedro"));
		
		Map<String, Double> alumnos = new HashMap<>();
		alumnos.put("Jorge", 9.8);
		alumnos.put("Ana", 3.7);
		alumnos.put("Miguel", 5.7);
		alumnos.put("Rocio", 9.8);
		alumnos.put("Angel", 6.5);
		alumnos.put("Sara", 8.3);
		
		var alumnos1 = new HashMap<>();
		var alumnos2 = new HashMap<String, Double>();
		var alumnos3 = new HashMap<String, Double>(alumnos);
		var alumnos4 = new HashMap<>(alumnos);

	}

}
