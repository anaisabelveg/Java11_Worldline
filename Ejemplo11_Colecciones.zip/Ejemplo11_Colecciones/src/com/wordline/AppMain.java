package com.wordline;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class AppMain {

	public static void main(String[] args) {
		
		// Set -> No permiten duplicados. No garantiza el orden de entrada
		Set conjunto = new HashSet();
		conjunto.add("Juan");
		conjunto.add(12);
		conjunto.add(true);
		conjunto.add('\n');
		conjunto.add("Juan");   // los repetidos los ignora
		
		System.out.println(conjunto);
		
		
		// List -> Si permiten duplicados. Si garantiza el orden de entrada
		List lista = new ArrayList();
		lista.add("Juan");
		lista.add(12);
		lista.add(true);
		lista.add('\n');
		lista.add("Juan"); 
		
		System.out.println(lista);
		
		
		// Tipos genericos
		Set<Integer> numeros = new HashSet<Integer>();
		numeros.add(1);
		numeros.add((int)2.2);
		numeros.add(Integer.parseInt("3"));
		numeros.add(new Integer(4));
		numeros.add(5);
		System.out.println(numeros);
		
		List<String> nombres = new ArrayList<>();
		nombres.add("Juan");
		nombres.add("Maria");
		nombres.add("Pedro");
		nombres.add("Laura");
		nombres.add("Jorge");
		System.out.println(nombres);
		
		// A partir de Java 9 permite crear listas o conjuntos inmutables
		List<String> dias = List.of("Lunes", "Martes", "Miercoles", "Jueves", "Viernes", "Sabado","Domingo");
		//dias.add("otro_sabado");   ERROR porque no se puede modificar
		
		Set<String> estados = Set.of("Soltero", "Casado", "Viudo", "Divorciado", "Pareja de hecho");

	}

}













