package com.worldline;

public class AppMain {

	public static void main(String[] args) {
		
		String cadena = "Bienvenidos al curso de Java";
		
		System.out.println("Longitud: " + cadena.length());
		System.out.println("Mayusculas: " + cadena.toUpperCase());
		System.out.println("Minusculas: " + cadena.toLowerCase());
		System.out.println("Primera a: " + cadena.indexOf("a"));
		System.out.println("Ultima a: " + cadena.lastIndexOf("a"));
		
		// Extraer la palabra Bienvenidos
		System.out.println(cadena.substring(0, cadena.indexOf(" ")));
		
		// Extraer la palabra Java
		System.out.println(cadena.substring(cadena.lastIndexOf(" ") +1 ));
		
		// Reemplazar la letra a por A
		System.out.println(cadena.replace('a', 'A'));
		
		
		// Numeros metodos en Java 11
		System.out.println("Hola".isBlank());
		System.out.println("".isBlank());
		System.out.println(" ".isBlank());
		System.out.println("\n".isBlank());
		System.out.println("\t".isBlank());
		
		System.out.println("-".repeat(20));
		System.out.println("*".repeat(20));
		
		String nombre = "         Juan          ";
		System.out.println("Hola, " + nombre + ".");
		System.out.println("Hola, " + nombre.trim() + ".");
		System.out.println("Hola, " + nombre.strip() + ".");
		System.out.println("Hola, " + nombre.stripTrailing() + ".");  // elimina espacios de la dcha
		System.out.println("Hola, " + nombre.stripLeading() + ".");   // elimina los espacios de la izda
		
	}

}









