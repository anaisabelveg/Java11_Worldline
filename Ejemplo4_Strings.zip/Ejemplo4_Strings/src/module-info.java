/**
 * 
 */
/**
 * 
 */
module Ejemplo4_Strings {
}