package com.wordline;

import java.util.Arrays;

import com.wordline.business.Calculadora;

public class AppMain {

	public static void main(String[] args) {
		
		System.out.println(Arrays.toString(args));
		
		int suma = 0;
		for (int i=0; i <= args.length; i++) {
			int numero = 0;
			
			// Anterior a Java 7
//			try {
//				String dato = args[i];
//				numero = Integer.parseInt(dato);
//			} catch (NumberFormatException ex) {
//				System.out.println("Error: El formato no es numerico");
//				System.out.println(ex.getMessage());
//			} catch (Exception e) {
//				e.printStackTrace();
//			} finally {
//				suma += numero;
//			}
			
			// A partir de Java 7 podemos agrupar las excepciones
			try {
				String dato = args[i];
				numero = Integer.parseInt(dato);
			} catch (NumberFormatException | ArrayIndexOutOfBoundsException ex) {
				if (ex.getClass().equals(NumberFormatException.class)){
					System.out.println("Error: El formato no es numerico");
				} else {
					System.out.println("Error: indice no existe");
				}
				System.out.println(ex.getMessage());
				ex.printStackTrace();
			} finally {
				suma += numero;
			}
			
		}
		
		System.out.println("Suma: " + suma);
		
		
		Calculadora calculadora = new Calculadora();
		System.out.println("7 / 5 = " + calculadora.dividir(7, 5));
		System.out.println("7 / 0 = " + calculadora.dividir(7, 0));
		
		
	}

}
