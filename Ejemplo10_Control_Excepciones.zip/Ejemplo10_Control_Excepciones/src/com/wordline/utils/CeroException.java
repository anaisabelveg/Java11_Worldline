package com.wordline.utils;

// Exception es checked -> obliga a tratar la excepcion con try-catch o throws
// RuntimeException es unchecked -> no me obliga a tratar
public class CeroException extends RuntimeException{
	
	public CeroException(String mensaje) {
		super(mensaje);
	}

}
