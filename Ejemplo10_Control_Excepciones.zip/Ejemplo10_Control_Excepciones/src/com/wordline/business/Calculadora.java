package com.wordline.business;

import com.wordline.utils.CeroException;

public class Calculadora {
	
	// .....
	
	// Puede ser que este metodo retorne el resultado de la divison
	// o puede ser que lance una excepcion
	public double dividir(int n1, int n2) throws CeroException {
		
		if (n2 == 0){
			// Lanzar una excepcion
			throw new CeroException("El divisor no puede ser cero");
		}
		
		return n1 / n2;
	}

}
