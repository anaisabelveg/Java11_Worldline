package com.wordline.persistence;

import java.util.Arrays;
import java.util.List;

import com.wordline.models.Producto;

// DAO -> Data Access Object
public class ProductosDAO {
	
	// Como no tenemos BBDD, lo simulamos
	List<Producto> lista = Arrays.asList(
			new Producto(1, "Pantalla", 129.95),
			new Producto(2, "Teclado", 43.80),
			new Producto(3, "Raton", 17.50),
			new Producto(4, "Scanner", 450),
			new Producto(5, "Impresora", 89.90)
	);
	
	public List<Producto> consultarTodos(){
		return lista;
	}
	
	public Producto buscarPorId(int id) {
		return lista.stream()
			.filter(prod -> prod.getID() == id)
			.findFirst()  // Me quedo con el primero del stream
			.orElse(new Producto());
	}

}
