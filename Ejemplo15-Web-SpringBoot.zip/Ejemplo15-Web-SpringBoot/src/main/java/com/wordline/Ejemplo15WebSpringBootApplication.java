package com.wordline;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejemplo15WebSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo15WebSpringBootApplication.class, args);
	}

}
